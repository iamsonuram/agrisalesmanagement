<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>home</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="css/style1.css">
	</head>
	<?php
		require 'menu.php';
	?>
	<div class="homeimage">
        <img src="images/image1.jpg" >
    </div>
	<div class="container">
		<center>
				<a href="signup.php"> <button class="buttonfit">REGISTER</button> </a>
		</center>
	</div>
	</body>
</html>